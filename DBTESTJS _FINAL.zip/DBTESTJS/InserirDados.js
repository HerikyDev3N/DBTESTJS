const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Proz@2023',
  database: 'CAPS'
});

connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados.');
});

const query = 'SELECT * FROM Dados_Pessoais';

connection.query(query, (err, result) => {
  if (err) {
    console.error('Erro ao realizar a consulta:', err);
    return;
  }
  console.log('Resultado da consulta:', result);
});

connection.end((err) => {
  if (err) {
    console.error('Erro ao encerrar a conexão:', err);
    return;
  }
  console.log('Conexão encerrada.');
});

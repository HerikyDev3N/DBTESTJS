const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;




// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir arquivos estáticos
app.use(express.static('public'));

// Rota para processar o formulário
app.post('/submit-form', (req, res) => {
    const { name, email, message } = req.body;
    console.log(`Nome: ${name}`);
    console.log(`E-mail: ${email}`);
    console.log(`Mensagem: ${message}`);
    res.send('Dados recebidos com sucesso!');
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});

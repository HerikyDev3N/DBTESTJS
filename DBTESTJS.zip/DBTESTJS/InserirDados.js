const mysql = require('mysql');

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
  host: 'localhost', // Substitua pelo seu host
  user: 'root', // Substitua pelo seu usuário
  password: 'Proz@2023', // Substitua pela sua senha
  database: 'CAPS' // Substitua pelo nome do seu banco de dados
});

// Conectando ao banco de dados
connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados.');
});

// Dados que serão inseridos
const dadosPessoais = {
  Nome: 'João Silva',
  CPF: '123.456.789-00',
  Idade: 30,
  Endereco: 'Rua A, 123'
};

// Query de inserção
const query = 'INSERT INTO Dados_Pessoais SET ?';

// Inserindo os dados
connection.query(query, dadosPessoais, (err, result) => {
  if (err) {
    console.error('Erro ao inserir dados:', err);
    return;
  }
  console.log('Dados inseridos com sucesso:', result);
});

// Encerrando a conexão
connection.end((err) => {
  if (err) {
    console.error('Erro ao encerrar a conexão:', err);
    return;
  }
  console.log('Conexão encerrada.');
});

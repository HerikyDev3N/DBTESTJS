const mysql = require('mysql');
const CryptoJS = require('crypto-js'); // Certifique-se de que o módulo crypto-js está instalado

const chave = 'PROTECTION_KEY'; // A mesma chave utilizada para criptografar os dados

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Proz@2023',
  database: 'CAPS'
});

// Conectar ao banco de dados
connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados.');
});

// Função para descriptografar dados
function decryptData(encryptedData) {
  const bytes = CryptoJS.AES.decrypt(encryptedData, chave);
  return bytes.toString(CryptoJS.enc.Utf8);
}

// Consulta SQL para obter os dados da tabela
const query = 'SELECT * FROM Form_Dados';

connection.query(query, (err, results) => {
  if (err) {
    console.error('Erro ao realizar a consulta:', err);
    connection.end();
    return;
  }

  results.forEach(row => {
    console.log('Nome:', decryptData(row.Nome));
    console.log('Email:', decryptData(row.Email));
    console.log('Mensagem:', decryptData(row.Mensagem));
    console.log('---');
  });

  // Encerrar a conexão
  connection.end((err) => {
    if (err) {
      console.error('Erro ao encerrar a conexão:', err);
      return;
    }
    console.log('Conexão encerrada.');
  });
});

const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');

const app = express();
app.use(bodyParser.json()); // Para processar o JSON vindo no body da requisição

// Configuração da conexão com o banco de dados
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Proz@2023',
  database: 'CAPS'
});

// Conectar ao banco de dados
connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados.');
});

// Servir o arquivo HTML na rota principal (/)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Rota POST para receber os dados do formulário e inseri-los no banco de dados
app.post('/submit', (req, res) => {
  const { nome_criptografado, email_criptografado, message_criptografado } = req.body;

  // Verificando se todos os campos estão presentes
  if (!nome_criptografado || !email_criptografado || !message_criptografado) {
    res.status(400).send('Dados incompletos.');
    return;
  }

  // Consulta SQL para inserir os dados na tabela
  const query = 'INSERT INTO Form_Dados (Nome, Email, Mensagem) VALUES (?, ?, ?)';

  connection.query(query, [nome_criptografado, email_criptografado, message_criptografado], (err, result) => {
    if (err) {
      console.error('Erro ao inserir os dados no banco de dados:', err);
      res.status(500).send('Erro ao inserir os dados');
      return;
    }
    res.status(200).send('Dados inseridos com sucesso!');
  });
});

// Iniciar o servidor na porta 3000
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
